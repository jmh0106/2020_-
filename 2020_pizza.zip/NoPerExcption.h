#pragma once
class NoPerExcption
{
};

