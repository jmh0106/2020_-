#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>

using namespace std;

bool getStu(ifstream& stuFlie, int& stuID, int& exam1, int& exam2, int& finalExam)
{
	stuFlie >> stuID >> exam1 >> exam2 >> finalExam;
	if (stuFlie)
		return true;
	else
		return false;
}

void calcGrade(int& stuID, int& exam1, int& exam2, int& finalExam, int& arvg, char& grade)
{
	arvg = (exam1 + exam2 + finalExam) / 3;

	if (arvg >= 90)
		grade = 'A';
	else if (arvg >= 80)
		grade = 'B';
	else if (arvg >= 70)
		grade = 'C';
	else if (arvg >= 60)
		grade = 'D';
	else if (arvg >= 50)
		grade = 'E';
}

void writeStu(ofstream& gradeFile, int stuID, int avrg, char grade)
{
	gradeFile.fill("0");
	gradeFile << setw(4) << stuID;
	gradeFile.fill(' ');
	gradeFile << setw(3);
	gradeFile << ' ' << grade << endl;
}

int main()
{
	ifstream stuFlie;
	cout << "���α׷� ����" << endl;
	stuFlie.open("ch7STUFL.DAT");
	if (stuFlie)
	{
		cerr << "���Ͽ��� ����" << endl;
		exit(102);
	}

	ofstream gradesFile;
	int stuld, exam1, exam2, finalExam, avrg;
	char grade;

	while (getStu(stuFlie, exam1, exam2, finalExam, avrg))
	{
		calcGrade(stuld, exam1, exam2, finalExam, avrg);
		writeStu(gradesFile, exam1, exam2, finalExam, avrg);
	}

	stuFlie.close();
	gradesFile.close();
}