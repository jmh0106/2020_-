#include <iostream>
#include "DataMan.h"

void main()
{
	cout << DataMgr->getLevel();
}