#include <iostream>
#include <fstream>
using namespace std;

void SaveFlie()
{
	string s;
	ofstream o("abc.txt");
	cout << "���Ͽ� �Է��� ������ �־��ּ��� : ";
	cin >> s;

	for (int i = 0; i < 3; i++)
		o << s << endl;

	o.close();
}

void ReadFlie()
{
	string s;
	ifstream i("abs.txt");

	if (i.is_open())
	{
		while (i.is_open())
			cout << s << endl;
	}

	i.close();
}

int main()
{
	SaveFlie();
}