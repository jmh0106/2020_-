#include <iostream>
#include <list>
using namespace std;

bool preicate(int num)
{
	return num >= 37 && num < 100;
}

void main()
{
	bool done = false;
	char command;
	int value;
	list<int> commandList;

	while (!done)
	{
		cout << "���ɾ� �Է�" << endl;
		cin >> command;

		switch (command)
		{
		case 'I':
		case 'i':
			if (cin >> value)
				commandList.push_back(value);
			else
				done = true;
			break;

		case 'P':
		case 'p':
			for (const auto& elem : commandList)
				cout << elem << ' ';
			cout << endl;
			break;

		case 'L':
		case 'l':
			cout << "Numbers of Element : " << commandList.size() << endl;
			break;

		case 'E':
		case 'e':
			commandList.clear();
			break;

		case 'Q':
		case'q':
			done = true;
		}
	}
}