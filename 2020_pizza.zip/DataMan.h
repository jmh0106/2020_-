#include <iostream>
#include <string>
#define DataMgr DataMan::instance()
using namespace std;

class DataMan
{
	string name = "�÷��̾�";
	int level = 37;
	int exp = 1000000;
public:
	DataMan()
	{

	}

	static DataMan* instance()
	{
		static DataMan inst;
		return &inst;
	}

	int getLevel()
	{
		return level;
	}
};