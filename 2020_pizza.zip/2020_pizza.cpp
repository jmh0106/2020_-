﻿#include <iostream>

using namespace std;

int main()
{
    int pizza_slices = 0;
    int persons = -1;
    int slices_per_person = 0;

    try
    {
        cout << "피자 조각수를 입력하시오";
        cin >> pizza_slices;
        cout << "사람수를 입력하시오";
        cin >> persons;

        if (persons == 0)
            throw persons;

        slices_per_person = pizza_slices / persons;
    }
    catch (int a)
    {
        cout << "사람이 " << a << "명 입니다.";
    }

    cout << "한사람당 피자는" << slices_per_person;
}

int DividePizza(int _pizzaSlice, int _person)
{
    return _pizzaSlice / _person;
}